# Include News TypoScript
<INCLUDE_TYPOSCRIPT: source="FILE: EXT:fluxtemplate/Configuration/TypoScript/Extensions/news.ts">

# Include Powermail TypoScript
<INCLUDE_TYPOSCRIPT: source="FILE: EXT:fluxtemplate/Configuration/TypoScript/Extensions/powermail.ts">