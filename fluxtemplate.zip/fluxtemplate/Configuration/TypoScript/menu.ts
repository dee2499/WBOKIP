
##############################
####   MAIN MENU  ####
##############################

lib.mainMenu = COA
lib.mainMenu{
	
	10= HMENU
	10.special = directory
	10.special.value = {$config.pid.mainMenu}
	10.1 = TMENU
	10.1 {
		wrap = <ul class="nav navbar-nav">|</ul>
		noBlur = 1
		expAll = 1
		IFSUB = 1  
		ACTIFSUB = 1
		CUR = 1
	
		NO {
			wrapItemAndSub = <li>|</li>
			ATagTitle.field = 1
		}

		ACT = 1
		ACT{
			wrapItemAndSub =  <li class="active">|</li>
			ATagTitle.field = 1
			stdWrap.htmlSpecialChars = 1
			ATagParams = class="active"
		}
	
		IFSUB{
			wrapItemAndSub = <li class="dropdown">|</li>
			ATagTitle.field = 1
		}

		ACTIFSUB {
			wrapItemAndSub = <li class="dropdown active">|</li>
			ATagTitle.field = 1
		}
	}

	10.2  = TMENU
	10.2 {
		wrap =  <span class="dropdown-toggle mobile-down" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="caret"></span></span><ul class="dropdown-menu">|</ul>
		noBlur = 1
		expAll = 1
		IFSUB = 1  
		
		NO {
			wrapItemAndSub.insertData = 1
			wrapItemAndSub = <li>|</li>
			ATagTitle.field = 1
			ATagParams = class=""
			stdWrap.htmlSpecialChars = 1
			ATagParams = class="active"
		}
		
		ACT = 1
		ACT{
			wrapItemAndSub.insertData = 1
			wrapItemAndSub = <li>|</li>
			ATagTitle.field = 1
			ATagParams = class="active"
		}
	}
}

##############################
####   FOOTER MENU  ####
##############################

lib.footerMenu = COA
lib.footerMenu {
	10 = HMENU
	10 {
	   special = directory
	   special.value = {$config.pid.footerMenu}
		1 = TMENU
		1 {
			wrap = <ul class="list-unstyled list-inline">|</ul>
			expAll = 1
			noBlur = 1
			NO = 1
		   # NO.ATagParams = target="_blank"
			NO {
				ATagTitle.field = abstract // description // title			   
				wrapItemAndSub = <li>|</li>
			}
			ACT < .NO
			ACT {
				wrapItemAndSub = <li class="active">|</li>
			}
			CUR < .ACT
		}	   
	}
}


lib.languageMenu = HMENU
lib.languageMenu {
	special = language
	special.value = 0,1
	special.normalWhenNoLanguage = 0
	1 = TMENU
	1 {
		# Normal link to language that exists:
		wrap = <ul class="nav navbar-nav navbar-right">|</ul>
		NO = 1
		#NO.allWrap = <li> |</li> || <li> |</li> 
		NO.allWrap = |*| |  |*| |
		NO.linkWrap = <li>|</li>

		#NO.linkWrap = | 
		
		NO.stdWrap.setCurrent = <img src="typo3conf/ext/fluxtemplate/Resources/Public/Images/language-1.png" class="img-responsive"> || <img src="typo3conf/ext/fluxtemplate/Resources/Public/Images/language-2.png" class="img-responsive">

		NO.ATagTitle  = German || English 
		NO.stdWrap.current = 1
		NO.doNotLinkIt = 1
		NO.stdWrap.typolink.parameter.data = page:uid
		NO.stdWrap.typolink.additionalParams = &L=0 || &L=1
		NO.stdWrap.typolink.addQueryString = 1
		NO.stdWrap.typolink.addQueryString.exclude = id,cHash,no_cache
		NO.stdWrap.typolink.addQueryString.method = GET
		NO.stdWrap.typolink.useCacheHash = 0
		NO.stdWrap.typolink.no_cache = 0

		# Current language selected:

		ACT = 1
		ACT < .NO
		ACT.ATagParams = class = "active"
		#ACT.linkWrap =  <li> |</li> || <li class = "active"> |</li> 
		ACT.linkWrap = <li class="active"> | </li>
		#ACT.stdWrap = <li class="active"> | </li>

		
		# Language that is NOT available:
		USERDEF1 < .NO
		USERDEF1.linkWrap = <li>|</li>
		USERDEF1.doNotLinkIt = 1
	}
}