﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _introduction:

Introduction
============


.. _what-it-does:

What does it do?
----------------

This chapter should give a brief overview of the extension. What does it do? What problems does it solve?
Who is interested in this? Basically, this section includes everything people need to know to decide whether they
should go on with this extension or not.


.. _screenshots:

Screenshots
-----------

This chapter should help people figure how the extension works. Remove it
if not relevant.

.. figure:: ../Images/IntroductionPackage.png
   :width: 500px
   :alt: Introduction Package

   Introduction Package just after installation (caption of the image)

   How the Frontend of the Introduction Package looks like just after installation (legend of the image)
