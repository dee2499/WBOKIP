// fancybox
$(document).ready(function() {
	$('a.inquirbtn').click(function() {
		var baseurl = window.location.hostname;	
		var l_id = $(this).data('lid');
		var p_id = $(this).data('pid');
		var d_uid = $(this).data('uid');
		
	
	var scrolltop, htmlOrBody;

    var antiscrollevent = function(e) {
		$('head').append('<meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width;" />');
        e.preventDefault();
        $(htmlOrBody).scrollTop(scrolltop);
		window.addEventListener('load', function() {
                document.body.addEventListener('touchmove', function(e) {
                    e.preventDefault();
                }, false);
            }, false);
			
		document.body.addEventListener('touchmove', function(e){ e.preventDefault(); });
    };
	
	  $.fancybox({
		  	//scrolling   : 'hidden',
			//autoDimensions: false,
			type: 'iframe',
			href: "index.php?id="+l_id+"/?tx_property_property[extensionName]=property&tx_property_property[controller]=Inquirer&tx_property_property[action]=list&"+d_uid+"="+p_id+"&type=12345",
			openEffect: 'elastic',
			closeEffect: 'elastic',
			autoScale: false,
			speedIn: 1000,
			speedOut: 700,
			maxWidth: '700',
			minHeight: '650',		
			onComplete : function() {	
				$('#fancybox-frame').load(function() { 
					 $('#fancybox-content').height($(this).contents().find('body').height()+30);
				});
			},			
			scrolling: "yes",
			closeEffect: "elastic",
			beforeShow: function() {           
				htmlOrBody = $('body').scrollTop() != 0 ? 'body' : 'html';
				scrolltop = $(htmlOrBody).scrollTop();
				$(window).on('scroll', antiscrollevent);
        	},		
			afterClose: function() {            
				$(window).off('scroll', antiscrollevent);
			}			 
	  });
	});
	
	// contact form validation
	jQuery("#contactform").validationEngine('attach', {
		promptPosition: "topLeft",
		validationEventTrigger: "submit",
		validateNonVisibleFields: true,
		updatePromptsPosition: true
	});
});

var keys = [37, 38, 39, 40];

    function preventDefault(e) {
      e = e || window.event;
      if (e.preventDefault) e.preventDefault();
      e.returnValue = false;  
    }

    function keydown(e) {
        for (var i = keys.length; i--;) {
            if (e.keyCode === keys[i]) {
                preventDefault(e);
                return;
            }
        }
    }

    function wheel(e) {
      preventDefault(e);
    }

    function disable_scroll() {
      if (window.addEventListener) {
          window.addEventListener('DOMMouseScroll', wheel, false);
      }
      window.onmousewheel = document.onmousewheel = wheel;
      document.onkeydown = keydown;
    }

    function enable_scroll() {
        if (window.removeEventListener) {
            window.removeEventListener('DOMMouseScroll', wheel, false);
        }
        window.onmousewheel = document.onmousewheel = document.onkeydown = null;  
    }


var metaslider_182 = function($) {
	
	$('#metaslider_182_filmstrip').flexslider({
		animation:'slide',
		controlNav:false,
		animationLoop:false,
		slideshow:false,
		itemWidth:150,
		itemMargin:5,
		asNavFor:'#metaslider_182',
		directionNav:true,
	});
	$('#metaslider_182').flexslider({ 
		slideshowSpeed:10000,
		animation:"fade",
		controlNav:false,
		directionNav:true,
		pauseOnHover:true,
		direction:"horizontal",
		reverse:false,
		animationSpeed:600,
		prevText:false,
		nextText:false,
		slideshow:true,
		sync:'#metaslider_182_filmstrip',
		before: function(slider) {
			if (slider.currentSlide + 1 == slider.count) { $('#metaslider_182_filmstrip').flexslider(0); }
		}
	});
};
var timer_metaslider_182 = function() {
	var slider = !window.jQuery ? window.setTimeout(timer_metaslider_182, 100) : !jQuery.isReady ? window.setTimeout(timer_metaslider_182, 1) : metaslider_182(window.jQuery);
};
timer_metaslider_182();
    
 // <![CDATA[
	var disqus_shortname = 'metaslider';
	(function () {
		var nodes = document.getElementsByTagName('span');
		for (var i = 0, url; i < nodes.length; i++) {
			if (nodes[i].className.indexOf('dsq-postid') != -1) {
				nodes[i].parentNode.setAttribute('data-disqus-identifier', nodes[i].getAttribute('rel'));
				url = nodes[i].parentNode.href.split('#', 1);
				if (url.length == 1) { url = url[0]; }
				else { url = url[1]; }
				nodes[i].parentNode.href = url + '#disqus_thread';
			}
		}
		var s = document.createElement('script'); 
		s.async = true;
		s.type = 'text/javascript';
		s.src = '//' + disqus_shortname + '.disqus.com/count.js';
		(document.getElementsByTagName('HEAD')[0] || document.getElementsByTagName('BODY')[0]).appendChild(s);
	}());
	// ]]> 



// print
function printDiv()
{	
	$("#printdiv").printElement({
		leaveOpen:true,
		printMode:'popup',		
	});	
}

// radio validation
function checkradio() {
   if ($('input[type=radio]:checked').length < 1) {
      $('.check_error').text('Bitte wählen Objektkategorie.');
      return false;
   }
   else {
      $('.check_error').remove();
      $('#search_form').submit();
   }
} 