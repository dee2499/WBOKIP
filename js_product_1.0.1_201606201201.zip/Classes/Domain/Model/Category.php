<?php
namespace JS\JsProduct\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Category
 */
class Category extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * background
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    protected $background = NULL;
    
    /**
     * hoverImage
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    protected $hoverImage = NULL;
    
    /**
     * title
     *
     * @var string
     */
    protected $title = '';
    
    /**
     * shortDescription
     *
     * @var string
     */
    protected $shortDescription = '';
    
    /**
     * image
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    protected $image = NULL;
    
    /**
     * Returns the background
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $background
     */
    public function getBackground()
    {
        return $this->background;
    }
    
    /**
     * Sets the background
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $background
     * @return void
     */
    public function setBackground(\TYPO3\CMS\Extbase\Domain\Model\FileReference $background)
    {
        $this->background = $background;
    }
    
    /**
     * Returns the hoverImage
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $hoverImage
     */
    public function getHoverImage()
    {
        return $this->hoverImage;
    }
    
    /**
     * Sets the hoverImage
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $hoverImage
     * @return void
     */
    public function setHoverImage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $hoverImage)
    {
        $this->hoverImage = $hoverImage;
    }
    
    /**
     * Returns the title
     *
     * @return string title
     */
    public function getTitle()
    {
        return $this->title;
    }
    
    /**
     * Sets the title
     *
     * @param string $title
     * @return string title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }
    
    /**
     * Returns the shortDescription
     *
     * @return string shortDescription
     */
    public function getShortDescription()
    {
        return $this->shortDescription;
    }
    
    /**
     * Sets the shortDescription
     *
     * @param string $shortDescription
     * @return string shortDescription
     */
    public function setShortDescription($shortDescription)
    {
        $this->shortDescription = $shortDescription;
    }
    
    /**
     * Returns the image
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference image
     */
    public function getImage()
    {
        return $this->image;
    }
    
    /**
     * Sets the image
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference image
     */
    public function setImage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $image)
    {
        $this->image = $image;
    }

}