<?php
namespace JS\JsProduct\Domain\Repository;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 projecp. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Products
 */
class ProductRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{

	/**
	 * @param $settings
	 */
	function getCategory($settings)
	{
		if ($GLOBALS['TSFE']->sys_language_uid > 0) {
			$field1 = ' , GROUP_CONCAT( concat( \'cat_\', l10n_parent ) SEPARATOR \' \' ) AS catClass ';
		} else {
			$field1 = ' , GROUP_CONCAT( concat( \'cat_\', uid ) SEPARATOR \' \' ) AS catClass ';
		}
		$field = '*' . $field1;
		$table = 'tx_jsproduct_domain_model_category';

		if ($GLOBALS['TSFE']->sys_language_uid > 0) {
			$whrLan = ' AND sys_language_uid = ' . $GLOBALS['TSFE']->sys_language_uid;
		}else{
			$whrLan = ' AND sys_language_uid IN (-1,0) ';
		}

		$where = ' hidden = 0 AND deleted = 0 '.$whrLan;

		$groupBy = ' uid ';
		if ($settings['pid'] != '') {
			$where .= ' AND pid = ' . $settings['pid'];
		}
		return $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy);
	}

	/**
	 * @param $uid
	 * @param $settings
	 */
	public function getSubCategory($settings, $uid = 0)
	{
		$GLOBALS['TSFE']->set_no_cache();

		if ($settings['pid'] != '') {
			$where .= ' AND s.pid = ' . $settings['pid'];
		}
		if ($uid > 0) {
			if ($GLOBALS['TSFE']->sys_language_uid > 0) {
				$where .= ' AND s.l10n_parent = ' . $uid;
			} else {
				$where .= ' AND s.uid = ' . $uid;
			}
		}

		if ($GLOBALS['TSFE']->sys_language_uid > 0) {
			$where .= ' AND s.sys_language_uid = ' . $GLOBALS['TSFE']->sys_language_uid;
		}else{
			$where .= ' AND s.sys_language_uid IN (-1,0) ';
		}

		if ($GLOBALS['TSFE']->sys_language_uid > 0) {
			$field2 = ' , s.l10n_parent as detail';
			$id = 'l10n_parent';
		} else {
			$field2 = ' , s.uid as detail';
			$id = 'uid';
		}

		$field1 = $field2 . ' , GROUP_CONCAT( concat( \'cat_\', c.'.$id.' ) SEPARATOR \' \' ) AS catClass ';
		
		$field = 's.*,GROUP_CONCAT(c.title SEPARATOR \', \' ) as cat_title, GROUP_CONCAT(c.uid) as categoryID ' . $field1;

		$table = 'tx_jsproduct_domain_model_subcategory AS s
						LEFT JOIN tx_jsproduct_domain_model_category AS c ON s.category = c.' . $id;
		$groupBy = ' s.uid ';
		$orderBy = ' s.uid desc';
		$teams = $this->getDBHandle()->exec_SELECTgetRows($field, $table, 's.deleted = 0 AND s.hidden = 0 ' . $where, $groupBy, $orderBy);

		//echo $this->getDBHandle()->SELECTquery($field, $table, 's.deleted = 0 AND s.hidden = 0 ' . $where, $groupBy, $orderBy); die;
	
		$data = $this->FalImage($teams, 'tx_jsproduct_domain_model_subcategory');

		$arr = array();

		foreach($data as $val){
			$arr[$val['uid']] = $val;
		}

		if ($uid > 0) {

			return $arr[$uid];
		}

		return $arr;
	}  

	/**
	 * @param $settings
	 * @param $uid
	 * @param $sid
	 */
	public function product($settings, $uid = 0, $sid = 0)
	{
		$GLOBALS['TSFE']->set_no_cache(); 

		if ($settings['pid'] != '') {
			$where .= ' AND p.pid = ' . $settings['pid'];
		}
		if ($uid > 0) {
			if ($GLOBALS['TSFE']->sys_language_uid > 0) {
				$where = ' AND p.l10n_parent = ' . $uid;
			} else {
				$where = ' AND p.uid = ' . $uid;
			}
		}

		$search = 0;

		if ($sid > 0) {
			$search = 1;
			/*
			if ($GLOBALS['TSFE']->sys_language_uid > 0) {
				$where = ' AND s.l10n_parent = ' . $sid;
			} else {
				$where = ' AND s.uid = ' . $sid;
			}
			*/
		}
		

		$where .= ' AND p.sys_language_uid = ' . $GLOBALS['TSFE']->sys_language_uid;

		if ($GLOBALS['TSFE']->sys_language_uid > 0) {
			$field2 = ' , p.l10n_parent as detail';
			$id = 'l10n_parent';
		} else {
			$field2 = ' , p.uid as detail';
			$id = 'uid';
		}

		// $field = 'p.*,GROUP_CONCAT(s.title SEPARATOR \', \' ) as sub_categories' . $field2;
		$field = 'p.*,GROUP_CONCAT(s.uid SEPARATOR \', \' ) as sub_uid' . $field2;
		$table = 'tx_jsproduct_domain_model_product AS p 

						LEFT JOIN tx_jsproduct_product_subcategory_mm AS m ON m.uid_local = p.uid 
						LEFT JOIN tx_jsproduct_domain_model_subcategory AS s ON m.uid_foreign = s.' . $id;

		$groupBy = ' p.uid ';
		$orderBy = ' p.uid desc';

		$product = $this->getDBHandle()->exec_SELECTgetRows($field, $table, 'p.deleted = 0 AND p.hidden = 0 ' . $where, $groupBy, $orderBy);

		$subCatArr = $this->getSubCategory($settings);

		$arr = array();

		foreach($product as $val){

			$arr1 = \TYPO3\CMS\Core\Utility\GeneralUtility::trimExplode(",",$val['sub_uid']);

			$subCat1 = array();
			
			foreach($arr1 as $val1){
				
				$subCat1[$val1] = $subCatArr[$val1]['title'];
				
			}
				

			if($search==1){
				if($sid != '' &&  strstr($val['sub_uid'],$sid)){
					$arr[$val['uid']] = $val;
					$arr[$val['uid']]['subCategory'] = $subCat1;
				
				}
				continue;
			}
			
			$arr[$val['uid']] = $val;
			$arr[$val['uid']]['subCategory'] = $subCat1;


		}

	   //echo $this->getDBHandle()->SELECTquery($field, $table, 'p.deleted = 0 AND p.hidden = 0 ' . $where,$groupBy,$orderBy);	die;

		$data = $this->FalImage($arr, 'tx_jsproduct_domain_model_product');

		if ($uid > 0) {
			foreach($data as $val){
				return $val;
			}
		}

		return $data;
	}
	
	/**
	 * FalImage
	 *
	 * @param $result
	 * @param $tablename
	 * @param $fieldname
	 * @return
	 */
	public function FalImage($result, $tablename = NULL, $fieldname = NULL)
	{
		// $query = $this->createQuery();
		// $query->getQuerySettings()->setReturnRawQueryResult(TRUE);
		$where = '';
		if ($tablename != '') {
			$where = ' AND tablenames = "' . $tablename . '"';
		}
		if ($fieldname != '') {
			$where .= ' AND fieldname IN ("' . $fieldname . '")';
		}
		foreach ($result as $key => $value) {
			$whr = ' deleted= 0 and hidden = 0 ' . $where . ' AND uid_foreign = ' . $value['uid'];
			$sysImages = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*', 'sys_file_reference', $whr, '', 'sorting_foreign ASC', '');
			$arr = '';
			foreach ($sysImages as $key1 => $value1) {
				$fields1 = '*';
				$table1 = 'sys_file';
				$where1 = 'uid = ' . $value1['uid_local'];
				$groupBy1 = $orderBy1 = $limit1 = '';
				$sysImageDetail = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($fields1, $table1, $where1, $groupBy1, $orderBy1, $limit1);

				$arr[$value1['fieldname']][$value1['uid']]['identifier'] = 'fileadmin' . $sysImageDetail[0]['identifier'];
				$arr[$value1['fieldname']][$value1['uid']]['title'] = $value1['title'];
				$arr[$value1['fieldname']][$value1['uid']]['caption'] = $value1['description'];
				$arr[$value1['fieldname']][$value1['uid']]['extension'] = $sysImageDetail[0]['extension'];
				$arr[$value1['fieldname']][$value1['uid']]['mime_type'] = $sysImageDetail[0]['mime_type'];
				$arr[$value1['fieldname']][$value1['uid']]['name'] = $sysImageDetail[0]['name'];
				$arr[$value1['fieldname']][$value1['uid']]['uid'] = $sysImageDetail[0]['uid'];
				$arr1 = \TYPO3\CMS\Core\Utility\GeneralUtility::trimExplode('/', $sysImageDetail[0]['mime_type'], true);
				$arr[$value1['fieldname']][$value1['uid']]['mime'] = $arr1[0];
				$arr[$value1['fieldname']][$value1['uid']]['type'] = $arr1[1];
				$arr[$value1['fieldname']][$value1['uid']]['imageName'] = basename($sysImageDetail[0]['identifier']);
			}
			$result[$key]['media'] = $arr;
		}
		return $result;
	}
	
	/**
	 * getDBHandle
	 *
	 * @return
	 */
	public function getDBHandle()
	{
		return $GLOBALS['TYPO3_DB'];
	}
	
}