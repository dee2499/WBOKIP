

jQuery(function(){
	jQuery(".team-grid .btn-team").click(function(){
		jQuery(".team-grid .btn-team").removeClass('btn-default').addClass('btn-small');
		jQuery(this).addClass('btn-default').removeClass('btn-small');
		var _data_target = jQuery(this).attr('data-tg');			
		if(_data_target == 'all'){
			jQuery(".team-list").fadeIn();
		}else{
			jQuery(".team-list").fadeOut();
		}	
		jQuery(".team-list").each(function(){
			var _data_tar = jQuery(this).attr('data-show');
			if(_data_tar.indexOf(_data_target) != -1){
			   jQuery(this).fadeIn();
			}
		});
	});
});

