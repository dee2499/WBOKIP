<?php

class tx_agproject_realurl {

        /**
         * Generates additional RealURL configuration and merges it with provided configuration
         *
         * @param       array           $params Default configuration
         * @param       tx_realurl_autoconfgen          $pObj   Parent object
         * @return      array           Updated configuration
         */
  function addAgProjectConfig($params, &$pObj) {
                return array_merge_recursive($params['config'], array(
                'postVarSets' => array(
                        '_DEFAULT' => array(
                                'prj' => array(
                                        array(
                                                'GETvar' => 'projectID',
                                                'lookUpTable' => array(
                                                    'table' => 'tx_agproduct_domain_model_product',
                                                    'id_field' => 'uid',
                                                    'alias_field' => 'title',
                                                    'useUniqueCache' => 1,
                                                    'useUniqueCache_conf' => array(
                                                        'strtolower' => 1,
                                                        'spaceCharacter' => '-',
                                                    ),
                                                ),
                                        ),
                                ),
                                'image3x' => array(
                                        array(
                                                'GETvar' => 'tx_album3x_pi1[showUid]',
                                                'userFunc' => 'EXT:album3x/class.tx_album3x_realurl.php:&tx_album3x_realurl->main',
                                        ),
                                ),
                    ))));
        }
}

?>