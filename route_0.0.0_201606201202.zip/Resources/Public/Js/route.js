var source, destination;
var directionsDisplay;
var directionsService = new google.maps.DirectionsService();
google.maps.event.addDomListener(window, 'load', function () {
    new google.maps.places.SearchBox(document.getElementById('txtSource'));
    new google.maps.places.SearchBox(document.getElementById('txtDestination'));
    directionsDisplay = new google.maps.DirectionsRenderer({ 'draggable': true });
});

window.onload = function() {

   if(document.getElementsByClassName("route-data").length>0){
         //alert('top_else');
        GetRoute();
    }    
};

function GetRoute() {
    // var val = document.getElementById('txtSource').value;
    // if (/^\s*$/.test(val)){
    //     $('#ajax_msg').html("<p class='alert alert-block alert-error fade in'>Enter Source Point.</p>").fadeIn();
    //     return false;
    // }
    var lat = document.getElementById("routeMap").getAttribute("data-lat");
    var longi = document.getElementById("routeMap").getAttribute("data-long");
    var zoom = document.getElementById("routeMap").getAttribute("data-zoom");
    var text = document.getElementById("txtDestination").value;
   

    if(lat==''){
        lat = 48.260870;
    }
    if(longi==''){
        longi = 13.047247;
    }
    if(zoom==''){
        zoom = 7;
    }

    var austria = new google.maps.LatLng(lat, longi);
    var mapOptions = {
        zoom: +zoom,
        center: austria,
        disableAutoPan:true,
        navigationControl:false,
        mapTypeControl:false,
    };


    map = new google.maps.Map(document.getElementById('routeMap'), mapOptions);
    var myLatlng = new google.maps.LatLng(lat,longi);

    var marker = new google.maps.Marker({
    position: myLatlng,
    title:"Hello World!"
    });
    marker.setMap(map);

    var infowindow = new google.maps.InfoWindow({
    content: text
  });

 
  marker.addListener('click', function() {
    infowindow.open(map, marker);
  });

    directionsDisplay.setMap(map);
    directionsDisplay.setPanel(document.getElementById('dvPanel'));
 
    //*********DIRECTIONS AND ROUTE**********************//
    source = document.getElementById("txtSource").value;
    destination = document.getElementById("txtDestination").value;
 
    var request = {
        origin: source,
        destination: destination,
        travelMode: google.maps.TravelMode.DRIVING
    };
    directionsService.route(request, function (response, status) {
        if (status == google.maps.DirectionsStatus.OK) {
            directionsDisplay.setDirections(response);
        }
    });
 
    //*********DISTANCE AND DURATION**********************//
    var service = new google.maps.DistanceMatrixService();
    service.getDistanceMatrix({
        origins: [source],
        destinations: [destination],
        travelMode: google.maps.TravelMode.DRIVING,
        unitSystem: google.maps.UnitSystem.METRIC,
        avoidHighways: false,
        avoidTolls: false
    }, function (response, status) {
        if (status == google.maps.DistanceMatrixStatus.OK && response.rows[0].elements[0].status != "ZERO_RESULTS") {
           // var distance = response.rows[0].elements[0].distance.text;
           // var duration = response.rows[0].elements[0].duration.text;
            
        } else {
            console.log("Nicht in der Lage , die Entfernung über die Straße zu finden");
        }
    });
}

