$(document).ready(function(){
	//Comment section score
	$('#scoreName').raty({ scoreName: 'cscore' , path: 'typo3conf/ext/blog/Resources/Public/Scripts/images' });
	
	//Previously added comments 
	$('.non-comments-rating').raty({ 
		path		: 'typo3conf/ext/blog/Resources/Public/Scripts/images',
		score 		: function() {return $(this).attr('data-score');},
		readOnly	: true 
	});

	//Previously added comments 
	$('.comments-rating').raty({ 
		path: 'typo3conf/ext/blog/Resources/Public/Scripts/images',
		score: function() {return $(this).attr('data-score');},
		click: function(score, evt) {
			//eturn false;		 
		 	console.log($(this));
    		//alert('score: ' + score);
  		}
		//readOnly : true 
	});




});
	