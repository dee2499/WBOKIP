<?php
namespace WOI\Blog\Domain\Repository;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Posts
 */
class PostRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {
	
	public function listViewData($currentBljCat) {
		
		$where = 'deleted = 0 AND hidden = 0 AND FIND_IN_SET('.$currentBljCat.',category) AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		
		$res	=	$GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*','tx_blog_domain_model_post', ''.$where.'', '', 'uid DESC', '');
//		echo $GLOBALS['TYPO3_DB']->SELECTquery('*','tx_blog_domain_model_post', ''.$where.'', '', '', '');die;

		if(count($res)>0){
			for($i=0; $i<count($res); $i++){
				$p[$i]['uid']			=	$res[$i]['uid'];
				$p[$i]['post_title']	=	$res[$i]['post_title'];
				$p[$i]['image']			=	$res[$i]['image'];
				$p[$i]['description']	=	$res[$i]['description'];
			}
		}
//		echo '<pre>';print_r($p);echo '</pre>';	die;	
		return $p;
	}
	
	public function saveCmtData( $conf = array() ) {
		$flag		=	0;
		$today		=	time();
		$pid		=	$conf['detailpage'];
		
		if(empty($conf['detailpage'])){
			$pid	=	1;
		}
		$id			=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('id');
		$blgid		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('blgid');
		$ctitle		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('ctitle');
		$cname		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('cname');
		$cemail		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('cemail');
		$ccmt		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('ccmt');
		$btncmt		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('btncmt');
		$score		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('cscore');	
		$cruserid	=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('cruserid');
		
		if($cemail!= ''){
			$insArr  = array(
								'pid' 				=> $pid,
								'tstamp'			=> time(),
								'crdate'			=> time(),
								'deleted' 			=> 0,
								'hidden' 			=> 0,
								
								'comment_title'		=> $ctitle,
								//'approved' 			=> 0,
								'approved' 			=> 1,
								'date' 				=> $today,
								'post' 				=> $blgid,
								'name' 				=> $cname,
								'email' 			=> $cemail,
								'comment_details'	=> $ccmt,
								'score'				=> 1,	
								'userid'			=> $cruserid
								
						);
			//echo '<pre>';print_r($insArr);echo '</pre>';	die;					
			$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;		
			$GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_blog_domain_model_comment', $insArr);
			$parent = $GLOBALS['TYPO3_DB']->sql_insert_id();
			$insArr  =	array( 	
					'score'		=> $score,
					'users'		=> $GLOBALS["TSFE"]->fe_user->user["uid"] ,
					'parent' 	=> $parent,
					'tstamp'	=> time(),
					'crdate' 	=> time(),
					'pid'		=> 99,
					'comment'   => $parent,
					'post'   => $blgid,
			);
				
				
			$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
			$GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_blog_domain_model_commentscore', $insArr);
			echo $GLOBALS['TYPO3_DB']->debug_lastBuiltQuery ;
			$updateCount	=	$this->updateCmtCount($blgid);
			//exit;			
			$flag	=	1;							
		}		
		return $flag;
	}
	
	public function updateCmtCount($bid) {
		
		$where	='deleted = 0 AND hidden = 0 AND uid = '.$bid.' AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTgetRows('comment_count','tx_blog_domain_model_post', ''.$where.'', '', '', '');
//		echo '<pre>';print_r($res);echo '</pre>';	die;
		if(empty($res[0]['comment_count'])){
			$count	=	0;
		}else{
			$count	=	$res[0]['comment_count'];
		}
		$updateArr  =	array( 'comment_count'		=> ($count+1)	);
		$where 		=	'uid = '.$bid. '';					
		$GLOBALS['TYPO3_DB']->exec_UPDATEquery('tx_blog_domain_model_post', ''.$where.'', $updateArr);
		return true;
		
	}
	
	public function getCmts($bid) {
		$where	=' comment.deleted = 0 AND comment.hidden = 0 AND comment.post = '.$bid.' AND comment.approved=1 AND comment.sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
				'comment.*,group_concat(commentscore.score) as scoreOrg',
				'tx_blog_domain_model_comment as comment LEFT JOIN tx_blog_domain_model_commentscore as commentscore ON (commentscore.parent = comment.uid)', 
				''.$where.'', 'comment.uid', '', '');
		//echo $GLOBALS['TYPO3_DB']->debug_lastBuiltQuery;
		if(count($res)>0){
			for($i=0; $i<count($res); $i++){
				$p[$i]['uid']				=	$res[$i]['uid'];
				$p[$i]['comment_title']		=	$res[$i]['comment_title'];
				$p[$i]['name']				=	$res[$i]['name'];
				$p[$i]['email']				=	$res[$i]['email'];
				$p[$i]['comment_details']	=	$res[$i]['comment_details'];		
				$p[$i]['date']				=	$res[$i]['date'];
				$p[$i]['approved']			=	$res[$i]['approved'];
				$p[$i]['post']				=	$res[$i]['post'];
				$p[$i]['score']				=	$res[$i]['scoreOrg'];							
			}
		}
//		echo '<pre>';print_r($p);echo '</pre>';	die;	
		return $p;		
	}

	public function getLastBlogId() {
		$where	='deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTgetRows('uid','tx_blog_domain_model_post', ''.$where.'', '', 'uid DESC', '0,1');
//		echo $GLOBALS['TYPO3_DB']->SELECTquery('*','tx_blog_domain_model_post', ''.$where.'', '', 'uid DESC', '0,1');
		return $res[0]['uid'];	
	}	

	public function saveCmtReplyData( $conf = array() ) {
		$flag		=	0;
		$today		=	time();
		$pid		=	$conf['detailpage'];
		
		if(empty($conf['detailpage'])){
			$pid	=	1;
		}
	
		$id					=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('id');
		$blgid				=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('blgid');
		$ctitle				=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('crtitle');
		$cname				=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('crname');
		$cemail				=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('cremail');
		$ccmt				=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('crcmt');
		$crcmtid			=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('crcmtid');
		$score				=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('crscore');	
		$parentcmtid		=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('parentcmtid');
		$cruserid			=	\TYPO3\CMS\Core\Utility\GeneralUtility::_GP('cruserid');
		
		if($cemail!= ''){
			$insArr  = array(
								'pid' 				=> $pid,
								'tstamp'			=> time(),
								'crdate'			=> time(),
								'deleted' 			=> 0,
								'hidden' 			=> 0,
								
								'replycomment_title'	=> $ctitle,
								//'approved' 			=> 0,
								'approved' 			=> 1,
								'date' 				=> $today,
								'post' 				=> $blgid,
								'comment'           => $crcmtid,
								'name' 				=> $cname,
								'email' 			=> $cemail,
								'replycomment_details'	=> $ccmt,
								'score'				=> (!empty($score)) ? $score : 0 ,	
								'parent_comment'	=> $parentcmtid	,
								'userid'			=> $cruserid
								
						);
			//echo '<pre>';print_r($insArr);echo '</pre>';	die;					
			$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;		
			$GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_blog_domain_model_replytocomment', $insArr);
			$parent = $GLOBALS['TYPO3_DB']->sql_insert_id();
			$insArr1  =	array(
					'score'		=> $score,
					'users'		=> $GLOBALS["TSFE"]->fe_user->user["uid"] ,
					'parent' 	=> $parent,
					'tstamp'	=> time(),
					'crdate' 	=> time(),
					'pid'		=> 99
			);
			$GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_blog_domain_model_replycommentscore', $insArr1);
			//print_r($_REQUEST); 
			//echo $GLOBALS['TYPO3_DB']->debug_lastBuiltQuery;
			//exit;
			$flag	=	1;							
		}		
		return $flag;
	}
	
	public function getReplytoCmts($bid , $parent ) {
		$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
		$where	='comment.deleted = 0 AND comment.hidden = 0 AND comment.comment = '.$bid.' AND comment.parent_comment = '.$parent.'  AND comment.approved=1 AND comment.sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTgetRows('comment.*,group_concat(commentscore.score) as scoreOrg','tx_blog_domain_model_replytocomment as comment LEFT JOIN  tx_blog_domain_model_replycommentscore as commentscore ON (commentscore.parent = comment.uid)', ''.$where.'', 'comment.uid', '', '');
		//		echo $GLOBALS['TYPO3_DB']->SELECTquery('*','tx_blog_domain_model_comment', ''.$where.'', '', '', '');die;
		//echo $GLOBALS['TYPO3_DB']->debug_lastBuiltQuery;
		if(count($res)>0){
			for($i=0; $i<count($res); $i++){
				
				$p[$i]['uid']				=	$res[$i]['uid'];
				$p[$i]['comment_title']		=	$res[$i]['replycomment_title'];
				$p[$i]['name']				=	$res[$i]['name'];
				$p[$i]['email']				=	$res[$i]['email'];
				$p[$i]['comment_details']	=	$res[$i]['replycomment_details'];
				$p[$i]['date']				=	$res[$i]['date'];
				$p[$i]['approved']			=	$res[$i]['approved'];
				$p[$i]['post']				=	$res[$i]['post'];
				$p[$i]['score']				=	$res[$i]['scoreOrg'];
				$p[$i]['parent_comment']	=	$res[$i]['parent_comment'];
				$p[$i]['comment']			=	$res[$i]['comment'];
				//$p[$i]['replytoComments']	= 	$this->getReplytoCmts( $bid, $p[$i]['uid']	);
			}
		}
		//echo '<pre>';print_r($p);echo '</pre>';	die;
		return $p;
	}
	
	public function updateScore($configId , $score , $post ) {
		//echo $GLOBALS["TSFE"]->fe_user->user["uid"];
		if ( !empty($GLOBALS["TSFE"]->fe_user->user["uid"])){
			$tableRcd = array("replycommentscore"=>"tx_blog_domain_model_replycommentscore","commentscore" => "tx_blog_domain_model_commentscore" );
			$configArray = explode("-",$configId) ;
			$table = $tableRcd[$configArray[0]];
			$where	='users = '.$GLOBALS["TSFE"]->fe_user->user["uid"].' AND parent = '.$configArray[1];
			$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
			$res	=$GLOBALS['TYPO3_DB']->exec_SELECTcountRows('*',$table, ''.$where.'');
			if( !empty($res) ){
				return 0;
			}
			switch ($table){
				case 'tx_blog_domain_model_commentscore' :
					$insArr  =	array( 	'score'		=> $score	,
							'users'		=> $GLOBALS["TSFE"]->fe_user->user["uid"] ,
							'parent' 	=> $configArray[1],
							'comment'	=> $configArray[1],
							'post'		=> $post,
							'tstamp'	=> time(),
							'crdate' 	=> time(),
							'pid'		=> 99
					);
					$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
					$GLOBALS['TYPO3_DB']->exec_INSERTquery($table, $insArr);
					break;
				case 'tx_blog_domain_model_replycommentscore' :
					$insArr  =	array( 	'score'		=> $score	,
							'users'		=> $GLOBALS["TSFE"]->fe_user->user["uid"] ,
							'parent' 	=> $configArray[1],
							'tstamp'	=> time(),
							'crdate' 	=> time(),
							'pid'		=> 99
					);
					
					
					$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
					$GLOBALS['TYPO3_DB']->exec_INSERTquery($table, $insArr);
					break;
					
			}
			/* $insArr  =	array( 	'score'		=> $score	,
					'users'		=> $GLOBALS["TSFE"]->fe_user->user["uid"] ,
					'parent' 	=> $configArray[1],
					'tstamp'	=> time(),
					'crdate' 	=> time(),
					'pid'		=> 99
			);
			
			
			$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
			$GLOBALS['TYPO3_DB']->exec_INSERTquery($table, $insArr); */
			//echo $GLOBALS['TYPO3_DB']->debug_lastBuiltQuery;
			return 1;
		}else{
			return -1;
		}
		
	}
	
	
	/*public function isAlreadyCommented( $userId , $postId ) {
		$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
		$where	='userid = '.$userId.'  AND post = '.$postId.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTcountRows('uid','tx_blog_domain_model_comment', ''.$where.'', '', 'uid DESC', '0,1');
		echo $GLOBALS['TYPO3_DB']->debug_lastBuiltQuery;
		return $res;
	}
	*/
	public function isAlreadyCommented( $userId , $commentid , $post) {
		$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
		$where	='userid = '.$userId.'  AND parent_comment =  0 AND post =  '.$post.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTcountRows('uid','tx_blog_domain_model_replytocomment', ''.$where.'', '', 'uid DESC', '0,1');
			echo $GLOBALS['TYPO3_DB']->debug_lastBuiltQuery;
		return $res;
	}
	
	
	public function isAlreadyReplyed( $userId , $commentid ) {
		$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
		$where	='userid = '.$userId.'  AND parent_comment = '.$commentid.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTcountRows('uid','tx_blog_domain_model_replytocomment', ''.$where.'', '', 'uid DESC', '0,1');
	//	echo $GLOBALS['TYPO3_DB']->debug_lastBuiltQuery;
		return $res;
	}
	
	public function isAlreadyScored( $userId , $comment ) {
		$where	='users = '.$userId.'  AND comment = '.$comment.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTcountRows('uid','tx_blog_domain_model_commentscore', ''.$where.'', '', 'uid DESC', '0,1');
		return $res;
	}
	
	public function isAlreadyScoredForReply( $userId , $comment ) {
		$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
		$where	='users = '.$userId.'  AND parent = '.$comment.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTcountRows('uid','tx_blog_domain_model_replycommentscore', ''.$where.'');
		echo $GLOBALS['TYPO3_DB']->debug_lastBuiltQuery;
		//print_r($res);exit;
		return $res;
	}
	
	public function isAlreadyScoredForReplyAlt( $userId , $comment ) {
		$GLOBALS['TYPO3_DB']->store_lastBuiltQuery = 1;
		$where	='users = '.$userId.'  AND uid = '.$comment.' AND deleted = 0 AND hidden = 0 AND sys_language_uid ='.$GLOBALS['TSFE']->sys_language_uid.'';
		$res	=$GLOBALS['TYPO3_DB']->exec_SELECTcountRows('uid','tx_blog_domain_model_replycommentscore', ''.$where.'');
		echo $GLOBALS['TYPO3_DB']->debug_lastBuiltQuery;
		//print_r($res);exit;
		return $res;
	}
}