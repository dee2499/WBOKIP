<?php
namespace WOI\Blog\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * PostController
 */
class PostController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * postRepository
	 * 
	 * @var \WOI\Blog\Domain\Repository\PostRepository
	 * @inject
	 */
	protected $postRepository = NULL;

	/**
	 * action list
	 * 
	 * @return void
	 */
	public function listAction() {
		$posts = $this->postRepository->findAll();
		$this->view->assign('posts', $posts);
	}

	/**
	 * action listView
	 * 
	 * @return void
	 */
	public function listViewAction() {
		if(!empty($this->settings['blogcategory'])){
			$listView = $this->postRepository->listViewData($this->settings['blogcategory']);
			$this->view->assign('settings', $this->settings);				
			$this->view->assign('listView', $listView);				
		}			
	}

	/**
	 * action detailView
	 * 
	 * @return void
	 */
	public function detailViewAction() {
		echo 1; die;
		if(!empty($_POST['action'])){
			$result = $this->postRepository->updateScore( $_REQUEST['source'] ,$_REQUEST['value'] ,  $_GET['blgid'] );
			echo $result;
			exit;
		}
		
		if($_POST['btncmt']){
		//	echo '<pre>';print_r($this->settings);echo '</pre>';	die;
			$this->postRepository->saveCmtData( $this->settings );			
		}	
		if($_POST['btnrecmt']){
			$this->postRepository->saveCmtReplyData( $this->settings );	
		}
		
		if($_GET['blgid'] && $_GET['blgid']!=''){
			$blgDetail 		= $this->postRepository->findByUid($_GET['blgid']);
			$getcmtsDetail	= $this->postRepository->getCmts($_GET['blgid']);
			
			foreach ( $getcmtsDetail as $key => $comments ){
				if( !empty($comments['score']) ){
					$count = count(explode(',',$comments['score']));
					$sumRecds = array_sum(explode(',',$comments['score']));
					$getcmtsDetail[$key]['score'] = ( ($sumRecds/$count) > 5 ) ? 5 : ($sumRecds/$count);
					echo $alreadyScored = $this->postRepository->isAlreadyScored($GLOBALS["TSFE"]->fe_user->user["uid"],$comments['uid'] );
					$getcmtsDetail[$key]['alreadyscore'] = !empty( $alreadyScored ) ? False : TRUE;
				}
				$alreadyCommented = $this->postRepository->isAlreadyCommented($GLOBALS["TSFE"]->fe_user->user["uid"],$_GET['blgid'],$_GET['blgid']);
				$getcmtsDetail[$key]['showReplyBox']  =  !empty( $alreadyCommented) ? false : true;
				
				if ( !empty($this->postRepository->getReplytoCmts($comments['uid'],0 ) ) )
					$getcmtsDetail[$key]['reply'] = $this->postRepository->getReplytoCmts($comments['uid'] , 0);
			}
			
			foreach ( $getcmtsDetail as $key => $comments ){
				if ( $getcmtsDetail[$key]['reply'] )
					foreach ( $getcmtsDetail[$key]['reply'] as $innerkey => $replyComments ){
					if( !empty($replyComments['score']) ){
						$count = count(explode(',',$replyComments['score']));
						$sumRecds = array_sum(explode(',',$replyComments['score']));
						$getcmtsDetail[$key]['reply'][$innerkey]['score'] = ( round($sumRecds/$count) > 5 ) ? 5 : round($sumRecds/$count);
					}
					$alreadyScored = $this->postRepository->isAlreadyScoredForReply($GLOBALS["TSFE"]->fe_user->user["uid"],$replyComments['uid'] );
					$getcmtsDetail[$key]['reply'][$innerkey]['alreadyscore'] = !empty( $alreadyScored ) ? TRUE : FALSE;
					$alreadyReplied  = $this->postRepository->isAlreadyReplyed($GLOBALS["TSFE"]->fe_user->user["uid"],$replyComments['uid']);
					$getcmtsDetail[$key]['reply'][$innerkey]['showReplyBox'] =  !empty( $alreadyReplied) ? false : true;
					$getcmtsDetail[$key]['reply'][$innerkey]['innercommet'] = $this->postRepository->getReplytoCmts($comments['uid'] , $replyComments['uid']);
					
					//echo "<pre>";print_r($getcmtsDetail[$key]['reply'][$innerkey]['innercommet']);
					
					if( !empty($getcmtsDetail[$key]['reply'][$innerkey]['innercommet'])){
						foreach ( $getcmtsDetail[$key]['reply'][$innerkey]['innercommet'] as $key1 => $value ){
							$alreadyScored = $this->postRepository->isAlreadyScoredForReply($GLOBALS["TSFE"]->fe_user->user["uid"],$value['uid'] );
							$getcmtsDetail[$key]['reply'][$innerkey]['innercommet'][$key1]['alreadyscore'] = !empty( $alreadyScored ) ? TRUE : FALSE;
							
							if( !empty($value['score']) ){
								$count = count(explode(',',$value['score']));
								$sumRecds = array_sum(explode(',',$value['score']));
								$getcmtsDetail[$key]['reply'][$innerkey]['innercommet'][$key1]['score'] = ( ($sumRecds/$count) > 5 ) ? 5 : ($sumRecds/$count);
							}
						}
					}
				}
			}
		
			//echo "<pre>";print_r($getcmtsDetail);exit;
			$loggedin = !empty( $GLOBALS["TSFE"]->fe_user->user["uid"] ) ? TRUE : FALSE; 
			$alreadyCommented = $this->postRepository->isAlreadyCommented($GLOBALS["TSFE"]->fe_user->user["uid"],$_GET['blgid']);
			
			$showCommentBox = ( $alreadyCommented==1) ? false : true;
			$this->view->assign('showCommentBox', $showCommentBox);
			$this->view->assign('name', $GLOBALS["TSFE"]->fe_user->user['name']);
			$this->view->assign('email', $GLOBALS["TSFE"]->fe_user->user['email']);
			$this->view->assign('uid', $GLOBALS["TSFE"]->fe_user->user["uid"]);
			$this->view->assign('loggedin', $loggedin);
			$this->view->assign('blgDetail', $blgDetail);
			$this->view->assign('getcmtsDetail', $getcmtsDetail);
		}else{
			$latestBlgId	=	$this->postRepository->getLastBlogId();
			$blgDetail 		= $this->postRepository->findByUid($latestBlgId);
			$getcmtsDetail	= $this->postRepository->getCmts($latestBlgId);
			
			$this->view->assign('blgDetail', $blgDetail);
			$this->view->assign('getcmtsDetail', $getcmtsDetail);			
		}		
	}

	/**
	 * action extraView1
	 * 
	 * @return void
	 */
	public function extraView1Action() {
		
	}

	/**
	 * action extraView2
	 * 
	 * @return void
	 */
	public function extraView2Action() {
		
	}

}