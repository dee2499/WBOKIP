<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'BridgeJobs.' . $_EXTKEY,
	'Job',
	array(
		'Jobs' => 'job',
		
	),
	// non-cacheable actions
	array(
		'Jobs' => 'job',
		
	)
);
## EXTENSION BUILDER DEFAULTS END TOKEN - Everything BEFORE this line is overwritten with the defaults of the extension builder