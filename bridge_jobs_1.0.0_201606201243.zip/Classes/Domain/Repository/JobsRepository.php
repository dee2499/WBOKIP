<?php
namespace BridgeJobs\BridgeJobs\Domain\Repository;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Jobs
 */
class JobsRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {
	
	
	/**
	 * getJobData
	 *
	 * @param $settings
	 * @param $job
	 *
	 * @return 
	 */
	public function getJobData($settings,$job){
		
		$this->fullURL	=  \TYPO3\CMS\Core\Utility\GeneralUtility::getIndpEnv('TYPO3_SITE_URL');
		
		$this->cObject	= \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('tslib_cObj');
		
		//$limit		= "";

		$orderBy	= "uid asc ";
	
		$field		= "uid, pid, title, teaser, description, file"; 

		$table		= "tx_bridgejobs_domain_model_jobs";
	
		//$groupBy	= "";

		$where		= " ";
		
		
		if (isset($settings['limit']) && $settings['limit'] > 0) {
			$limit = $settings['limit'];
		}
		
		$job = intval($job);
		
		if($job>0){
			$where 		= " AND uid =  '".$job."'";
		}else{

			if(isset($settings['storagePID']) && $settings['storagePID']!=""){
				$where .= " AND pid in (".$settings['storagePID'].") ";
			}	
		}
		
		$where 		= "deleted = 0 AND hidden = 0 ".$where;
		
		$Query = $this->createQuery();
		$Query->getQuerySettings()->setReturnRawQueryResult(TRUE);
		

		
		//$conf	= $this->getDBHandle()->exec_SELECTgetRows($field,$table,$where,$groupBy,$orderBy,$limit);
		
			if (isset($settings['limit']) && $settings['limit'] > 0) {
				$sql = 'SELECT '.$field.' from '.$table.' where '.$where.' order by '.'sorting'.' LIMIT '.$limit;
			} else {
				$sql = 'SELECT '.$field.' from '.$table.' where '.$where.' order by '.'sorting' ;
			} 
		
		
		// $sortBytype 	= !empty($settings['sortByType'])  ? ' '.$settings['sortByType'] : ''; 
		// $sortBy  		= !empty($settings['sortBy'])  ? $settings['sortBy'] : 'sorting';
		// if (isset($settings['limit']) && $settings['limit'] > 0) {
		// 	$sql = 'SELECT '.$field.' from '.$table.' where '.$where.' order by '.$sortBy.$sortBytype .' LIMIT '.$limit;
		// } else {
		// 	$sql = 'SELECT '.$field.' from '.$table.' where '.$where.' order by '.$sortBy.$sortBytype;
		// }
		
        $Query->statement($sql);
		
		//echo $this->getDBHandle()->SELECTquery($field,$table,$where,$groupBy,$orderBy,$limit);	die;
		$res = $this->falImages($Query->execute(), "tx_bridgejobs_domain_model_jobs");
		
		$data	= array();
		
		foreach ($res as $key => $value) {
			
			if(is_array($value['media'])){

				
				$fuid = $value['media']['media']['uid'];
				$mime = $value['media']['media']['mime'];;
				
				
				$link['additionalParams']	= "&tx_bridgejobs_download[action]=download&tx_bridgejobs_download[file]=".$value['uid'];
				$link['returnLast']			= 'url'; 
				$link['parameter']			= $GLOBALS['TSFE']->id;
				$detailLink					= $this->fullURL.$this->cObject->typolink(NULL, $link);
				
				$configurations['additionalParams']	= '&tx_bridgejobs_download[action]=download&tx_bridgejobs_download[docID]=' . base64_encode($fuid).'&tx_bridgejobs_download[media]=' . base64_encode($value['uid']);
				
				$configurations['returnLast']		= 'url';
				$configurations['parameter']		= $GLOBALS['TSFE']->id;
				$downlonadLink						= $this->fullURL.$this->cObject->typolink(NULL, $configurations);
				
				$data[$value['uid']]					= $value;
				$data[$value['uid']]['mime']			= $mime;
				//$data[$value['uid']]['detailLink']		= $detailLink;
				//$data[$value['uid']]['downlonadLink']	= $downlonadLink;
			}
		else {
			$data[$value['uid']]					= $value;
		}

		}
		
		/*echo "<pre>";
		print_r($data);
		echo "</pre>";
		exit;*/
		return $data;
		
	}
	/**
	 * downloadFile
	 *
	 * @param $id
	 * @param $media
	 * @param $path
	 * @return
	 */
	public function downloadFile($id,$media, $path) {
		
		$table = 'tx_bridgejobs_domain_model_jobs';
		
		$where = " uid = ".$media;		
		
		//$res = $this->getDBHandle()->exec_SELECTgetRows('no_of_download', $table,$where);
		
		//$fields_values = array("no_of_download" => ($res[0]['no_of_download']+ 1));

		$this->getDBHandle()->exec_UPDATEquery ($table, $where,$fields_values);

		/*
			$sql 	= "UPDATE tx_jsdownload_domain_model_file SET no_of_download=no_of_download + 1 WHERE uid = ".$media;		
			
			$query = $this->createQuery();
			$query->getQuerySettings()->setReturnRawQueryResult(TRUE);
			$query->statement($sql); 
			$query->execute(); 
		*/
		$resArr = $this->getDBHandle()->exec_SELECTgetRows('*', 'sys_file', 'uid in (\'' . $id . '\')');
		
		if (count($resArr) > 0) {
			$fullPath = $_SERVER['DOCUMENT_ROOT'] . "/".$path . $resArr[0]['identifier'];
			$image = $resArr[0]['name'];
			$this->downloadService->download($fullPath, $image);
		} else {
			$this->downloadService->noAccess();
		}
	}
	/**
	 * falImages
	 *
	 * @param $result
	 * @param $tablename
	 * @param $fieldname
	 * @return
	 */
    public function falImages($result, $tablename = NULL, $fieldname = NULL)
    {
        $query = $this->createQuery();
        $query->getQuerySettings()->setReturnRawQueryResult(TRUE);
        $where = "";
		
        if ($tablename != "") {
            $where = ' AND tablenames = "' . $tablename . '"';
        }
        if ($fieldname != "") {
            $where .= ' AND fieldname IN (' . $fieldname . ')';
        }
        foreach ($result as $key => $value) {
            
            $sysImage = 'SELECT * FROM sys_file_reference WHERE deleted= 0 and hidden = 0 ' . $where . ' AND uid_foreign = ' . $value['uid'] . ' ORDER BY sorting_foreign';
            
            $query->statement($sysImage);
            $sysImages = $query->execute();
            
			$arr = "";
			
			
			
            foreach ($sysImages as $key1 => $value1) {
				
                $sysImageDetail = 'SELECT * FROM sys_file WHERE uid = ' . $value1['uid_local'];
                $query->statement($sysImageDetail);
                $sysImageDetail = $query->execute();
               
                $arr[$value1['fieldname']]['identifier']	= $sysImageDetail[0]['identifier'];                
                $arr[$value1['fieldname']]['extension']		= $sysImageDetail[0]['extension'];
                $arr[$value1['fieldname']]['mime_type']		= $sysImageDetail[0]['mime_type'];
                $arr[$value1['fieldname']]['name']			= $sysImageDetail[0]['name'];
                $arr[$value1['fieldname']]['uid']			= $sysImageDetail[0]['uid'];
				
				$arr1	= \TYPO3\CMS\Core\Utility\GeneralUtility::trimExplode("/", $sysImageDetail[0]['mime_type'], true);	

				$arr[$value1['fieldname']]['mime']		= $arr1[0];
				$arr[$value1['fieldname']]['type']		= $arr1[1];
				
				$arr[$value1['fieldname']]['file']	= basename($sysImageDetail[0]['identifier']);
            }
			
            $result[$key]['media'] = $arr;
        }
        
        return $result;
    }


	/**
	 * getDBHandle
	 *
	 * @return 
	 */
	public function getDBHandle() {
		return $GLOBALS['TYPO3_DB'];
	}
	
}