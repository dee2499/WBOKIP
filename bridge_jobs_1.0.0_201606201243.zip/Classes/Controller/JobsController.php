<?php
namespace BridgeJobs\BridgeJobs\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * JobsController
 */
class JobsController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * jobsRepository
	 *
	 * @var \BridgeJobs\BridgeJobs\Domain\Repository\JobsRepository
	 * @inject
	 */
	protected $jobsRepository = NULL;

	/**
	 * action job
	 *
	 * @return void
	 */
	public function jobAction() {		
		$getData = \TYPO3\CMS\Core\Utility\GeneralUtility::_GP('tx_bridgejobs_job');		
		
		$detail 	= 0;
		
		// for getting link page id on read more buton
		$jobbackpagePID = $GLOBALS['TSFE']->id;
		
		if (isset($getData['job']) && $getData['job'] > 0) {
			$detail = intval($getData['job']);			
		}
		
		if ($this->request->hasArgument('docID')){
			$id = $this->request->getArguments();
			$id['docID'] = base64_decode($id['docID']);
			$docID = intval($id['docID']);
			$id['media'] = base64_decode($id['media']);
			$media = intval($id['media']);

			if($docID>0 && $media>0){
				$media = $this->jobsRepository->downloadFile($docID,$media,$this->settings['basePath']);
			}
		}
		
		// For getting Selected layout option
		$templatelayout = ($this->settings['templateLayout'] ? \TYPO3\CMS\Core\Utility\GeneralUtility::trimExplode(',', $this->settings['templateLayout']) : array());
		
		
		
		$data = $this->jobsRepository->getJobData($this->settings, $detail);
		
		$datacount = sizeof($data);
		
		$this->view->assign('job', $data);	
		
		$this->view->assign('setting', $this->settings);
		
		$this->view->assign('jobcount', $datacount);
		
		$this->view->assign('jobbackPID', $jobbackpagePID);
		
		$this->view->assign('templatelayout', $templatelayout);
		
	}

}