 $(document).ready(function() {

     if ($('.alert').hasClass('alert-success')) {
         $('#email').focus();
     }
    
     $('#email-form').validate();

     });