<?php
namespace TYPO3\Newsletter\Controller;
session_start();

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * NewsletterController
 */
  
use \TYPO3\CMS\Core\Utility\GeneralUtility;

class NewsletterController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * newsletterRepository
	 *
	 * @var \TYPO3\Newsletter\Domain\Repository\NewsletterRepository
	 * @inject
	 */
	protected $newsletterRepository = NULL;

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		
	
		$arguments = $this->request->getArguments();
		$email = $arguments['email']; 
                $name = $arguments['name']; 
		//$_SESSION['save'];
                $test = 0;
             
			if(isset($email)){
                            
				//if($_SESSION['save'] ==''){
                            if($test == 0){
                               
					$uid = $this->newsletterRepository->findUid();
					if($uid ==''){
						$array['uid'] 	 = 1;
					}else{
						$array['uid']   = $uid[0]['uid']+1;
					}
					$array['name']   = $email;
					$array['email']  = $email;
					$array['pid']    = $this->settings['newsletterStorage'];
					$array['tstamp'] = time();
					
                                        
					$email_check = $this->newsletterRepository->findEmail($email);		
					
					if($email_check[0]['email']==''){
						$newslettersSave= $this->newsletterRepository->saveDetails($array);
						//$_SESSION['save']=1;
                                                $test = 1;
                                                        $newsletters['thankyou_message'] = '1';
                                             
                                                $to = $email;
                                                $subject = $this->settings['subject'];
                                                $txt = $this->settings['Message'];
                                                $msg = html_entity_decode($txt, ENT_QUOTES);
                                                
                                                $header_email =  $this->settings['adminemail'];
                                                $adminName = 'BSM';
                                                //$this->sendMail($email,$subject,$txt,'',$headers,$adminName,'','','','');
                                               $headers  = 'MIME-Version: 1.0' . "\r\n";
                                               $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                                               $headers .= "From: $header_email";
                                               
                                                mail($to, $subject, $msg, $headers); 
                                               
                                               
                                                
					}else{
						$newsletters['alreadyRegister_message'] = '1';
					}					
					$this->view->assign('newsletters', $newsletters);
					$this->view->assign('settings', $this->settings);
				}else{
					//$_SESSION['save']='';	
                    $test = 0;
				}
                               
                                
		}
		
	}
        
//        public static function sendMail($to, $subject, $html, $plain, $fromEmail = '', $fromName = '', $replyToEmail = '', $replyToName = '', $returnPath = '', $attachements = array()) {
//
//                $emailLogo =$GLOBALS['TSFE']->tmpl->flatSetup['config.emailLogo'];
//                $baseURL = $GLOBALS['TSFE']->baseUrl;
//
//                 // Make instance of swiftmailer
//                 $message = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Mail\\MailMessage');
//
//                 // From
//                 if ($fromEmail) {
//                $message->setFrom(array($fromEmail => $fromName));
//                 }
//
//                 // To
//                 $recipients = array();
//                 if (is_array($to)) {
//                foreach ($to as $pair) {
//                 if (\TYPO3\CMS\Core\Utility\GeneralUtility::validEmail($pair['email'], false)) {
//                if (trim($pair['name'])) {
//                 $recipients[$pair['email']] = $pair['name'];
//                } else {
//                 $recipients[] = $pair['email'];
//                }
//                 }
//                }
//                 } else {
//                $recipients[] = $to;
//                 }
//
//                 if (!count($recipients)) {
//                return false;
//                 }
//
//                 $message->setTo($recipients);
//
//                 // Subject
//                 $message->setSubject($subject);
//
//                 // HTML
//                 $mail_html =  '<img src="'.$baseURL.$emailLogo.'" alt="Logo"  /><br/><br/>';
//                 $mail_html .= $html;
//
//                 $message->setBody($mail_html, 'text/html', 'utf-8');
//
//                 // Plain
//                 if ($plain) {
//                $message->addPart($plain, 'text/plain', 'utf-8');
//                 }
//
//                 // Return Path
//                 if (trim($returnPath)) {
//                $message->setReturnPath($returnPath);
//                 }
//
//                 // Reply To
//                 if (trim($replyToEmail) && \TYPO3\CMS\Core\Utility\GeneralUtility::validEmail($replyToEmail)) {
//                if (trim($replyToName)) {
//                 $message->setReplyTo(array($replyToEmail => $replyToName));
//                } else {
//                 $message->setReplyTo(array($replyToEmail));
//                }
//                 }
//
//                 // Attachements
//                 if (count($attachements)) {
//                foreach ($attachements as $file => $name) {
//                 if (file_exists($file)) {
//                if (trim($name)) {
//                 $message->attach(\Swift_Attachment::fromPath($file)->setFilename($name));
//                } else {
//                 $message->attach(Swift_Attachment::fromPath($file));
//                }
//                 }
//                }
//                 }
//
//                 // Mail Send
//                 $message->send();
//
//                 return true;
//                }

                }