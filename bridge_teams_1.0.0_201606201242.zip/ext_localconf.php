<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'BridgeTeams.' . $_EXTKEY,
	'Team',
	array(
		'Teams' => 'team',
		
	),
	// non-cacheable actions
	array(
		'Teams' => 'team',
		
	)
);
