<?php
namespace BridgeTeams\BridgeTeams\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * TeamsController
 */
class TeamsController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * teamsRepository
	 *
	 * @var \BridgeTeams\BridgeTeams\Domain\Repository\TeamsRepository
	 * @inject
	 */
	protected $teamsRepository = NULL;

	/**
	 * action team
	 *
	 * @return void
	 */
	public function teamAction() {
		
		$data = $this->teamsRepository->getTeamData($this->settings);	
		
		// For getting Selected layout option
		$templatelayout = ($this->settings['templateLayout'] ? \TYPO3\CMS\Core\Utility\GeneralUtility::trimExplode(',', $this->settings['templateLayout']) : array());
		
		
		$this->view->assign('team', $data);
		$this->view->assign('setting', $this->settings);
		$this->view->assign('templatelayout', $templatelayout);
	}

}