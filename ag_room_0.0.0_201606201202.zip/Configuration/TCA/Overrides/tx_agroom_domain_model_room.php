<?php


$GLOBALS['TCA']['tx_agroom_domain_model_room']['columns']['images']['config']['maxitems'] = 10;

$GLOBALS['TCA']['tx_agroom_domain_model_room']['columns']['website_url']['config'] = array(
		'type' => 'input',
		'size' => '50',
		'max' => '256',
		'eval' => 'trim',
		'wizards' => array(
		     'link' => array(
		             'type' => 'popup',
		             'title' => 'LLL:EXT:cms/locallang_ttc.xlf:header_link_formlabel',
		             'icon' => 'link_popup.gif',
		             'module' => array(
		                     'name' => 'wizard_element_browser',
		                     'urlParameters' => array(
		                             'mode' => 'wizard'
		                     )
		             ),
		             'params' => array(
		             	'blindLinkOptions' => 'file,page,mail,spec,folder',
		             ),
		             'JSopenParams' => 'height=300,width=500,status=0,menubar=0,scrollbars=1'
		     )
		),
		'softref' => 'typolink'
);

$GLOBALS['TCA']['tx_agroom_domain_model_room']['columns']['price']['config']['eval'] = 'double2';