<?php
namespace AG\AgRoom\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 room. The TYPO3 room is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Room
 */
class Room extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * title
     *
     * @var string
     */
    protected $title = '';
    
    /**
     * sorttext
     *
     * @var string
     */
    protected $sorttext = '';
    
    /**
     * description
     *
     * @var string
     */
    protected $description = '';
    
    /**
     * images
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    protected $images = '';
    
    /**
     * features
     *
     * @var string
     */
    protected $features = '';
    
    /**
     * minPerson
     *
     * @var string
     */
    protected $minPerson = '';
    
    /**
     * maxPerson
     *
     * @var string
     */
    protected $maxPerson = '';
    
    /**
     * singleRoomFee
     *
     * @var string
     */
    protected $singleRoomFee = '';
    
    /**
     * extraFee
     *
     * @var string
     */
    protected $extraFee = '';
    
    /**
     * links
     *
     * @var string
     */
    protected $links = '';
    
    /**
     * roomSize
     *
     * @var string
     */
    protected $roomSize = '';
    
    /**
     * meals
     *
     * @var string
     */
    protected $meals = '';
    
    /**
     * price
     *
     * @var string
     */
    protected $price = '';
    
    /**
     * view
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    protected $view = null;
    
    /**
     * additionalPriceInfo
     *
     * @var string
     */
    protected $additionalPriceInfo = '';
    
    /**
     * category
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\AG\AgRoom\Domain\Model\Category>
     * @cascade remove
     */
    protected $category = null;
    
    /**
     * season
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\AG\AgRoom\Domain\Model\Season>
     */
    protected $season = null;
    
    /**
     * realtedRooms
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\AG\AgRoom\Domain\Model\Room>
     */
    protected $realtedRooms = null;
    
    /**
     * Returns the title
     *
     * @return string $title
     */
    public function getTitle()
    {
        return $this->title;
    }
    
    /**
     * Sets the title
     *
     * @param string $title
     * @return void
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }
    
    /**
     * Returns the description
     *
     * @return string $description
     */
    public function getDescription()
    {
        return $this->description;
    }
    
    /**
     * Sets the description
     *
     * @param string $description
     * @return void
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }
    
    /**
     * Returns the images
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference images
     */
    public function getImages()
    {
        return $this->images;
    }
    
    /**
     * Sets the images
     *
     * @param string $images
     * @return void
     */
    public function setImages($images)
    {
        $this->images = $images;
    }
    
    /**
     * Returns the price
     *
     * @return string $price
     */
    public function getPrice()
    {
        return $this->price;
    }
    
    /**
     * Sets the price
     *
     * @param string $price
     * @return void
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }
    
    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }
    
    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->category = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->season = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->realtedRooms = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }
    
    /**
     * Adds a Category
     *
     * @param \AG\AgRoom\Domain\Model\Category $category
     * @return void
     */
    public function addCategory(\AG\AgRoom\Domain\Model\Category $category)
    {
        $this->category->attach($category);
    }
    
    /**
     * Removes a Category
     *
     * @param \AG\AgRoom\Domain\Model\Category $categoryToRemove The Category to be removed
     * @return void
     */
    public function removeCategory(\AG\AgRoom\Domain\Model\Category $categoryToRemove)
    {
        $this->category->detach($categoryToRemove);
    }
    
    /**
     * Returns the category
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\AG\AgRoom\Domain\Model\Category> category
     */
    public function getCategory()
    {
        return $this->category;
    }
    
    /**
     * Sets the category
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\AG\AgRoom\Domain\Model\Category> $category
     * @return void
     */
    public function setCategory(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $category)
    {
        $this->category = $category;
    }
    
    /**
     * Returns the features
     *
     * @return string $features
     */
    public function getFeatures()
    {
        return $this->features;
    }
    
    /**
     * Sets the features
     *
     * @param string $features
     * @return void
     */
    public function setFeatures($features)
    {
        $this->features = $features;
    }
    
    /**
     * Returns the minPerson
     *
     * @return string $minPerson
     */
    public function getMinPerson()
    {
        return $this->minPerson;
    }
    
    /**
     * Sets the minPerson
     *
     * @param string $minPerson
     * @return void
     */
    public function setMinPerson($minPerson)
    {
        $this->minPerson = $minPerson;
    }
    
    /**
     * Returns the maxPerson
     *
     * @return string $maxPerson
     */
    public function getMaxPerson()
    {
        return $this->maxPerson;
    }
    
    /**
     * Sets the maxPerson
     *
     * @param string $maxPerson
     * @return void
     */
    public function setMaxPerson($maxPerson)
    {
        $this->maxPerson = $maxPerson;
    }
    
    /**
     * Returns the singleRoomFee
     *
     * @return string $singleRoomFee
     */
    public function getSingleRoomFee()
    {
        return $this->singleRoomFee;
    }
    
    /**
     * Sets the singleRoomFee
     *
     * @param string $singleRoomFee
     * @return void
     */
    public function setSingleRoomFee($singleRoomFee)
    {
        $this->singleRoomFee = $singleRoomFee;
    }
    
    /**
     * Returns the extraFee
     *
     * @return string $extraFee
     */
    public function getExtraFee()
    {
        return $this->extraFee;
    }
    
    /**
     * Sets the extraFee
     *
     * @param string $extraFee
     * @return void
     */
    public function setExtraFee($extraFee)
    {
        $this->extraFee = $extraFee;
    }
    
    /**
     * Returns the links
     *
     * @return string $links
     */
    public function getLinks()
    {
        return $this->links;
    }
    
    /**
     * Sets the links
     *
     * @param string $links
     * @return void
     */
    public function setLinks($links)
    {
        $this->links = $links;
    }
    
    /**
     * Returns the roomSize
     *
     * @return string $roomSize
     */
    public function getRoomSize()
    {
        return $this->roomSize;
    }
    
    /**
     * Sets the roomSize
     *
     * @param string $roomSize
     * @return void
     */
    public function setRoomSize($roomSize)
    {
        $this->roomSize = $roomSize;
    }
    
    /**
     * Returns the meals
     *
     * @return string $meals
     */
    public function getMeals()
    {
        return $this->meals;
    }
    
    /**
     * Sets the meals
     *
     * @param string $meals
     * @return void
     */
    public function setMeals($meals)
    {
        $this->meals = $meals;
    }
    
    /**
     * Returns the view
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $view
     */
    public function getView()
    {
        return $this->view;
    }
    
    /**
     * Sets the view
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $view
     * @return void
     */
    public function setView(\TYPO3\CMS\Extbase\Domain\Model\FileReference $view)
    {
        $this->view = $view;
    }
    
    /**
     * Returns the additionalPriceInfo
     *
     * @return string $additionalPriceInfo
     */
    public function getAdditionalPriceInfo()
    {
        return $this->additionalPriceInfo;
    }
    
    /**
     * Sets the additionalPriceInfo
     *
     * @param string $additionalPriceInfo
     * @return void
     */
    public function setAdditionalPriceInfo($additionalPriceInfo)
    {
        $this->additionalPriceInfo = $additionalPriceInfo;
    }
    
    /**
     * Returns the sorttext
     *
     * @return string $sorttext
     */
    public function getSorttext()
    {
        return $this->sorttext;
    }
    
    /**
     * Sets the sorttext
     *
     * @param string $sorttext
     * @return void
     */
    public function setSorttext($sorttext)
    {
        $this->sorttext = $sorttext;
    }

}