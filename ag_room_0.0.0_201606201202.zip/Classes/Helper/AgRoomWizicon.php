<?php
/**
 * Created by Ajay Gohel.
 * User: Ajay
 */
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/**
 * Class that adds the wizard icon.
 */
class AgRoomWizicon {

    /**
     * Processing the wizard items array
     *
     * @param array $wizardItems : The wizard items
     * @return Modified array with wizard items
     */
    function proc( $wizardItems ) {

        $wizardItems['plugins_tx_room_room'] = array(
            'icon' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('ag_room') . 'Resources/Public/Icons/wizicon_room.png',
            'title' => $GLOBALS['LANG']->sL('LLL:EXT:ag_room/Resources/Private/Language/locallang.xlf:plugin-title'),
            'description' => $GLOBALS['LANG']->sL('LLL:EXT:ag_room/Resources/Private/Language/locallang.xlf:plugin-description'),
            'params' => '&defVals[tt_content][CType]=list&defVals[tt_content][list_type]=plugins_tx_room_room'
        );

        return $wizardItems;
    }
}
?>